# Load all necessary resources
from cs50 import SQL
from flask import Flask, redirect, render_template, request, session, jsonify
from flask_session import Session
import sqlite3, datetime

app = Flask(__name__)
db = SQL("sqlite:///orders.db")

# Set temporary variables for authentication
globalUsername = "placeholder"
globalPassword = "placeholder"


# Retrieve real credentials from database
def readSqliteTable():
    global globalUsername
    global globalPassword

    try:
        sqliteConnection = sqlite3.connect('login.db')
        cursor = sqliteConnection.cursor()
        sqlite_select_query = "SELECT * from login WHERE id = 1"
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        for row in records:
            username = row[1]
            password = row[2]
            globalUsername = username
            globalPassword = password
        cursor.close()

    except sqlite3.Error as error:
        print("Failed to read data from sqlite table", error)
    finally:
        if sqliteConnection:
            sqliteConnection.close()


# Define available purchase options
FOODS = [
    "Margherita",
    "Capricciosa",
    "Hawaiian",
    "Pepperoni",
    "Vegetarian"
]

# Configure sessions
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route("/")
def index():
    return render_template("index.html", foods=FOODS)

@app.route("/delete", methods=["POST"])
def delete():

    # Delete order
    id = request.form.get("id")
    if id:
        db.execute("DELETE FROM orders WHERE id = ?", id)
    return redirect("/orders")

# Register orders
@app.route("/register", methods=["POST"])
def register():

    # Get current date and time
    datetime_object = datetime.datetime.now()

    # Validate submission
    time = datetime_object.strftime('%d-%m-%Y  %H:%M')
    name = request.form.get("name")
    tel = request.form.get("tel")
    email = request.form.get("email")
    food = request.form.get("food-list")
    if not name or not tel or not food :
        return render_template("failure.html")

    # Record order into the database
    db.execute("INSERT INTO orders (time, name, tel, email, food) VALUES(?, ?, ?, ?, ?)", time, name, tel, email, food)

    # Confirm order
    return redirect("/success")

# Orders page
@app.route("/orders")
def orders():
    orders = db.execute("SELECT * FROM orders")
    return render_template("orders.html", orders=orders)

# Thank you page
@app.route("/success")
def success():
    return render_template("success.html")

# Login procedure
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":

        # Get credentials from database
        readSqliteTable()

        ############################################
        # Username = Admin
        # Password = 1Strongpassword!
        ############################################

        # Get info from user
        getUsername = request.form.get("user")
        getPassword = request.form.get("password")

        # Find match
        if (globalUsername != getUsername) or (globalPassword != getPassword) :
            session["authentication"] = "error"
            return render_template("login.html")

        session["authentication"] = "correct"
        session["user"] = getUsername
        session["password"] = getPassword
        return redirect("/orders")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session["user"] = None
    session["password"] = None
    session["authentication"] = None
    return redirect("/")

