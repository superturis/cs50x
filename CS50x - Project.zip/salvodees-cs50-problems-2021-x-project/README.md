# PRONTO PIZZA - Click and collect!
#### Video Demo:  https://youtu.be/B2KBcY64Nb4
#### Description:

An online booking system featuring a storefront page where users can place their orders and a private area that allows staff members to log in and check or delete reservations.

- application.py
This is the core of the system where everything is happening. All the commands for the database and whatever happens on the other pages is all managed through here.

- layout.html
This is the main structure of the website. It provides the website with a header, a main central place for other pages to be displayed and a footer. This page will always be loaded and the center of the page is where other pages will be dynamically loaded, reducing the amount of items to load and speeding up the website.

- index.html
This file contains the home page of the website. It's mainly made of two columns and some JavaScript code that is crucial for handling all the events in the page, including the products selection and transmission of the selection to the application.py file which is the one sending all data to the database.

- orders.html
This page is populated with orders info coming from application.py. It's a password protected page and in our restaurant project only staff members are supposed to access it.

- success.html
This is the confirmation page users will see after they have successfully placed an order.

- failure.html
This page shows up only if people are smart enough to bypass some of the mandatory fields in the home page using some coding tricks or if something really goes wrong (eg. a connection issue when submitting the form, etc.).

- login.html
This page features a log in area where users can enter their username and password. The information will be sent to application.py and if they match the credentials stored in the database will allow users to access the order page.

- styles.css
This is the stylesheet containing all the style for the different sections of the website. It also contains some media queries that are those making the website responsive. This file is located inside a "Static" folder along with the image featured in the home page.

- login.db
This file contains the credentials for accessing the restricted area. Since this project is a demo, a copy of the username and password has been copied inside a comment in the application.py file for testing purposes.

- orders.db
This database file contains all the info submitted by customers when placing their orders online.

- requirements.txt
This file contains a list of all dependencies.